package com.ashik.khamwallet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

object BkashParser {
    private const val PREF_NAME = "KhamWalletPrefs"
    private const val KEY_PENDING_EVENTS = "pending_bkash_events"

    data class ParsedTx(
        val type: String,
        val amount: Double,
        val balance: Double?,
        val title: String,
        val raw: String
    )

    fun parseMessage(sender: String, body: String): ParsedTx? {
        val lowerSender = sender.lowercase(Locale.getDefault())
        val lowerBody = body.lowercase(Locale.getDefault())

        if (!lowerSender.contains("bkash") && !lowerBody.contains("bkash") && !lowerBody.contains("trxid")) {
            return null
        }

        val isOut = lowerBody.contains("cash out") ||
                lowerBody.contains("send money") ||
                lowerBody.contains("payment") ||
                lowerBody.contains("mobile recharge") ||
                lowerBody.contains("paid tk") ||
                lowerBody.contains("sent tk")

        val isIn = lowerBody.contains("received tk") ||
                lowerBody.contains("cash in") ||
                lowerBody.contains("add money")

        if (!isOut && !isIn) return null

        val amtPattern = Pattern.compile("(?:tk|bdt)\s*([0-9,]+(?:\.[0-9]+)?)", Pattern.CASE_INSENSITIVE)
        val amtMatcher = amtPattern.matcher(body)
        if (!amtMatcher.find()) return null

        val amount = amtMatcher.group(1)?.replace(",", "")?.toDoubleOrNull() ?: return null
        if (amount <= 0) return null

        var newBalance: Double? = null
        val balPattern = Pattern.compile("balance\s*(?:is)?\s*(?:tk|bdt)\s*([0-9,]+(?:\.[0-9]+)?)", Pattern.CASE_INSENSITIVE)
        val balMatcher = balPattern.matcher(body)
        if (balMatcher.find()) {
            newBalance = balMatcher.group(1)?.replace(",", "")?.toDoubleOrNull()
        }

        val title = when {
            lowerBody.contains("cash out") -> "bKash Cash Out (লাইভ সিঙ্ক)"
            lowerBody.contains("send money") -> "bKash Send Money (লাইভ সিঙ্ক)"
            lowerBody.contains("payment") -> "bKash Payment (লাইভ সিঙ্ক)"
            lowerBody.contains("recharge") -> "Mobile Recharge (লাইভ সিঙ্ক)"
            lowerBody.contains("received") -> "bKash Money Received (লাইভ সিঙ্ক)"
            lowerBody.contains("cash in") -> "bKash Cash In (লাইভ সিঙ্ক)"
            else -> if (isIn) "bKash ইনকাম (লাইভ সিঙ্ক)" else "bKash খরচ (লাইভ সিঙ্ক)"
        }

        return ParsedTx(
            type = if (isIn && !isOut) "IN" else "OUT",
            amount = amount,
            balance = newBalance,
            title = title,
            raw = body
        )
    }

    fun queueEvent(context: Context, tx: ParsedTx) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_PENDING_EVENTS, "[]") ?: "[]"
        val arr = JSONArray(existing)
        val obj = JSONObject().apply {
            put("type", tx.type)
            put("amount", tx.amount)
            put("balance", tx.balance ?: -1.0)
            put("title", tx.title)
            put("time", SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date()))
        }
        arr.put(obj)
        prefs.edit().putString(KEY_PENDING_EVENTS, arr.toString()).apply()
    }

    fun popAllEvents(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_PENDING_EVENTS, "[]") ?: "[]"
        prefs.edit().putString(KEY_PENDING_EVENTS, "[]").apply()
        return existing
    }
}
