package com.ashik.khamwallet

import android.app.Notification
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BkashNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val pkg = sbn.packageName ?: return
        if (pkg.contains("bkash", ignoreCase = true) || pkg.contains("messaging", ignoreCase = true) || pkg.contains("mms", ignoreCase = true)) {
            val extras = sbn.notification.extras
            val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
            val parsed = BkashParser.parseMessage(title, "$title $text")
            if (parsed != null) {
                BkashParser.queueEvent(this, parsed)
                val broadcast = Intent("com.ashik.khamwallet.BKASH_LIVE_UPDATE")
                broadcast.setPackage(packageName)
                sendBroadcast(broadcast)
            }
        }
    }
}
