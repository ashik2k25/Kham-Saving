package com.ashik.khamwallet

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class BkashSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            var fullBody = ""
            var sender = ""
            for (sms in messages) {
                sender = sms.originatingAddress ?: ""
                fullBody += sms.messageBody ?: ""
            }
            val parsed = BkashParser.parseMessage(sender, fullBody)
            if (parsed != null) {
                BkashParser.queueEvent(context, parsed)
                val broadcast = Intent("com.ashik.khamwallet.BKASH_LIVE_UPDATE")
                broadcast.setPackage(context.packageName)
                context.sendBroadcast(broadcast)
            }
        }
    }
}
